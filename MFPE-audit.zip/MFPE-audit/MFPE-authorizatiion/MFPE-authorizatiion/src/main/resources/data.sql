insert into users (id, password, user_name) values (1, 'admin', 'admin');
insert into users (id, password, user_name) values (2, 'user1', 'user1');
insert into users (id, password, user_name) values (3, 'user2', 'user2');